#ifndef __CK_H
#define __CK_H

#include "main.h"   // Device header

extern uint8_t uart1_rxbuff;
extern uint8_t e;



void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);
	
#endif
