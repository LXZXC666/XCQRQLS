#ifndef __DEALY_h
#define __DEALY_h

#include "main.h"

void Delay_us(uint32_t us);
void my_delay_ms(uint32_t ms);

#endif /*__dht11_h*/
