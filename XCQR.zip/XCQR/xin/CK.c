#include "CK.h"                  // Device header
#include "usart.h"

uint8_t uart1_rxbuff;

uint8_t e;



void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	uint16_t tem;// �޷��š�
	
	if(huart->Instance== USART6)
	{   
		//RedSignal_Toggle;   //����Ƿ���յ����ݡ�
		
		tem=uart1_rxbuff;
	    	e=tem;
	//	Openmv_Receive_Data(tem);		
	}	
	HAL_UART_Receive_IT(&huart6,(void *)&uart1_rxbuff,1); 
}
