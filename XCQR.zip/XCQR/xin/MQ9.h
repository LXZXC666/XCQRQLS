#ifndef __MQ9_h
#define __MQ9_h



#include "main.h"                  // Device header
extern uint16_t ADC_Value;

uint8_t MQ9_ReadData(void);

#endif

