#ifndef __WYZDH_H
#define __WYZDH_H

#include "main.h"   


void USART3_SendData(uint8_t data);

unsigned char snr9816tts_say_sentence(uint8_t *sentence, uint8_t len);

	
	
#endif

