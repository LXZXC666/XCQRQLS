#ifndef _WIFE_H_
#define _WIFE_H_

#include "main.h"
extern uint8_t TQ,SJ,RQ;
void uart2_receiver_handle(void);
uint8_t esp8266_receive_msg(void);
uint8_t esp8266_send_msg(void);
void esp8266_init(void);
#endif

